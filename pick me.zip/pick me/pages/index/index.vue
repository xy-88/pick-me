<template>
	
	<view class="content">
		<web-view webview-styles="content" src="/hybrid/html/login.html" @message="getMessage"></web-view>
	</view>
	
</template>
<!-- uni 的 SDK -->
<script type="text/javascript" src="https://js.cdn.aliyun.dcloud.net.cn/dev/uni-app/uni.webview.1.5.2.js"></script>
<script>
var wv;//计划创建的webview
export default {
	data() {
		return {
			
		}
	},
	onLoad(){
		
	},
    onReady() {
       
    },
	methods: {
		
	}
    };
	
</script>

<style>
	.content {
		
		flex-direction: column;
		align-items: center;
		justify-content: center;
		
	}

</style>
