<template>
	<view class="content">
		<web-view webview-styles="content" src="/hybrid/html/FinPayS.html" @message="getMessage"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
